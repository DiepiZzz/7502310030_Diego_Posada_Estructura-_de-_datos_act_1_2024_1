
package pkg7502310030_diego_posada_estructura._de._datos_act_1_2024_1;

import java.util.Arrays;
import java.util.Random;

public class ventas_Class {
     int [] ventas;
     
     
    public ventas_Class(int[] ventas) {
        this.ventas = ventas;
    }
    
    public int sumaVentas(){
        int suma = 0;
        for (int v : ventas) { 
            suma += v;
        }
         return suma;
    } 
    
   public int ventAlt(){
       int ventaMasAlta = Integer.MIN_VALUE;
       for (int v : ventas){
           if (v > ventaMasAlta){
               ventaMasAlta = v;
           }
       }
       return ventaMasAlta;
   }
   
   public int ventBaj(){
       int ventaMasBaja = Integer.MAX_VALUE;
       for (int v : ventas){
           if (v < ventaMasBaja){
               ventaMasBaja = v;
           }
       }
       return ventaMasBaja;
       }
   public double promVentas(){
       int s = sumaVentas();
       return (double) s / ventas.length;
   }
   public int NumCercanoProm(){
       double prom = promVentas();
       int NumCercano = ventas[0];
       double menorDiferencia = Math.abs(ventas[0] - prom);
       
       for (int v: ventas){
           double diferencias = Math.abs(v - prom);
           if ( diferencias < menorDiferencia){
               menorDiferencia = diferencias;
               NumCercano = v;
           }
   }
return NumCercano;
   
    }
   
   
   
   public void OrdenarAscendentes(){
      Arrays.sort(ventas);
   
     }
public void OrdenarDescendentes(){
      Arrays.sort(ventas);
      reverseArrray(ventas);
    
}

    public void reverseArrray(int[] arr) {
        int left = 0;
        int right = arr.length - 1;
        while ( left < right){
            int t = arr[left];
            arr[left] = arr[right];
            arr[right] = t;
            left++;
            right--;        
        }
    }
        
    public void desordenar(){
            Random r = new Random();
            for (int i = ventas.length - 1; i > 0; i--){
              int j = r.nextInt(i + 1);
              int t = ventas[i];
              ventas[i] = ventas[j];
              ventas[j] = t;
            }
        
    }
    
    public void OrdParesEImpares (){
        Arrays.sort(ventas);
        int[] pares = new int[ventas.length];
        int[] impares = new int[ventas.length];
        int indPares = 0;
        int indImpares = 0;
        
        for (int v : ventas){
            if (v % 2 == 0){
                pares[indPares++] = v;
            }else {
                impares[indImpares++] = v;
            }
        }
      System.arraycopy(impares, 0, ventas, indPares, indImpares);
      System.arraycopy(pares, 0, ventas, 0, indPares);
    }

   
}

  
 


    
    

