
package pkg7502310030_diego_posada_estructura._de._datos_act_1_2024_1;

import java.util.Arrays;
import java.util.Scanner;


public class Matrices {

    
    public static void main(String[] args) {
       Object[][] lenguajes = new Object [5][8];
       lenguajes[0] = new Object[]{"NOMBRE", "AÑO", "AUTOR", "DETALLES", "FRAMEWORKS"};
       infoLenguajes(lenguajes);
      
       mostrarMtriz(lenguajes);
       boolean[] info = {true,  false, true, true, false};
     infoLenguajes(lenguajes, info);
 
    
        Scanner scn = new Scanner(System.in);
        System.out.println("Ingese elnombre de un lenguaje para buscar: ");
        String lenguajeB = scn.nextLine();
        int[] coords = buscarCoord(lenguajes, lenguajeB);
        if ( coords != null){
        System.out.println("el lenguaje \"" + lenguajeB + "\" se encuentra en la matriz: " + buscarLeng(lenguajes, lenguajeB));
        System.out.println("el lenguaje \"" + lenguajeB + "\" se encuentra en la fila: " + (coords [0] + 1) + " y columna " + (coords [1] + 1));

    }else {
            System.out.println("El lenguaje \"" + lenguajeB + "\" no se encuentra en la matriz");
        } 
        
       
        System.out.println("ingrese el numero de filas para obtener el registro completo: ");
        int filaB = scn.nextInt();
        try {
            Object[] registro = obtenerRegFila(lenguajes, filaB);
            System.out.println("Registro completo de la fila " + filaB + ": " + Arrays.toString(registro));
        }catch (IllegalArgumentException e){
            System.out.println(e.getMessage());
            
        }
        
        System.out.println("Ingresa el numero de columnas para obtener su registro completo: ");
        int buscarColumna = scn.nextInt();
        
        
        try{
            Object[] registroB = obtenerRegColumna(lenguajes, buscarColumna);
            
            System.out.println("Registro completo de la columna " + buscarColumna + ": " + Arrays.toString(registroB));
            
        } catch (IllegalArgumentException e){
            System.out.println("Columna no encontrada");
        }
        
}

    private static void infoLenguajes(Object[][] matriz) {
        Scanner s = new Scanner(System.in);
        for (int i = 1; i < matriz.length; i++){
            System.out.println("ingrese datos para la fila " + (i + 1) + ": ");
        for (int j = 0; j < matriz[i].length; j++){
            System.out.println("ingrese dato para la columna " + (j + 1) + ": ");
                matriz [i][j] = s.nextLine();
          }
        }
      }

    private static boolean buscarLeng(Object[][] matriz, String lenguaje) {
        for (Object[] fila : matriz){
            for(Object d : fila){
                if (d != null && d.equals(lenguaje)){
                    return true;
                    }
                }
            }
        return false;
        }
        private static int[] buscarCoord(Object[][] matriz, String lenguaje) {
            for ( int i = 0; i < matriz.length; i++){
                for (int j = 0; j < matriz[i].length; j++){
                    if (matriz[i][j] != null && matriz[i][j].equals(lenguaje)){
                        return new int[]{i,j};
                    }
                }
            }
            return null;
    }

    private static Object[] obtenerRegFila(Object[][] matriz, int fila) {
        if (fila < 0 || fila > matriz.length){
            throw new IllegalArgumentException("la fila especificada no existe en la matriz. ");
        }
        return matriz[fila - 1];
    }
    
    
    private static Object[] obtenerRegColumna (Object[][] matriz, int columna){
        if (columna < 0 || columna > matriz[0].length){
            throw new IllegalArgumentException("La columna especificada no existe en la matriz. ");
            
     }
       Object[] reg = new Object[matriz.length];
       for (int i = 0; i < matriz.length; i++){
       reg[i] = matriz[i][columna -1];
    
       }
       return reg;
    }

    private static void infoLenguajes(Object[][] matriz, boolean[] mostrarInfo) {
        for (int i = 0; i< mostrarInfo.length; i++){
            if (mostrarInfo[i]){
                System.out.println("Información de la categoría " + (i + 1) + ": ");
                for (int j = 0; j < matriz[0].length; j++){
                    if (!matriz[i][j].equals("")){
                        System.out.println("Lenguaje: " + matriz[0][j] + ", Autor: " + matriz[1][j] + ", Framework: " + matriz[2][j]);
                    }
            }
        }
    }
  }

    private static void mostrarMtriz(Object[][] matriz) {
        System.out.println("Matriz de lenguajes: ");
for (int i = 0; i < matriz.length; i++){
    for (int j = 0; j < matriz[i].length; j++){       
        System.out.println(matriz[i][j] + "\t");
            }
    System.out.println();   
        }
    }   

   
    }

    
    
 






                
            
        
            
        
    

     
    
    
        
    
    
    
    

