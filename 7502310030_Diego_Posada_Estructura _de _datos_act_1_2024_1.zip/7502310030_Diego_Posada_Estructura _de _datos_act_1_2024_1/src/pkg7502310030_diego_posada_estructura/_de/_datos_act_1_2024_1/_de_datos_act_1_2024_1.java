
package pkg7502310030_diego_posada_estructura._de._datos_act_1_2024_1;

import java.util.Arrays;
import java.util.Random;
import java.util.Scanner;

public class _de_datos_act_1_2024_1 {

    public static void main(String[] args) {
      
        byte [] numeros = new byte [5];
        
        numeros [0] = -125;
        numeros [1] = -102;    
        numeros [2] = -50;
        numeros [3] = 75;
        numeros [4] = 100;
        
        for (byte i = 0; i <numeros.length; i++)
            System.out.println("el dato tipo byte en la posición " + i + ": " + numeros[i]);
         System.out.println("----------------------------------------------------------");
         
        char [] letras = new char [5];
        
        letras [0] = 'a';
        letras [1] = 'b';
        letras [2] = 'x';
        letras [3] = 'y';
        letras [4] = 'z';
        
         for (int i = 0; i < letras.length; i++)
            System.out.println("el dato tipo char en la posición " + i + ": " + letras[i]);
         System.out.println("----------------------------------------------------------");
         
        short [] shortNum = new short [5];
        
        shortNum [0] = -30500;
        shortNum [1] = -20050;
        shortNum [2] = -3400;
        shortNum [3] = 100;
        shortNum [4] = 5000;
        
         for (int i = 0; i < shortNum.length; i++)
            System.out.println("el dato tipo short en la posición " + i + ": " + shortNum[i]);
         System.out.println("----------------------------------------------------------");
        
        int [] intNum = new int [5];
        
        intNum [0] = 50;
        intNum [1] = 45;
        intNum [2] = -60;
        intNum [3] = -70;
        intNum [4] =  100;
        
         for (int i = 0; i < intNum.length; i++)
            System.out.println("el dato tipo int en la posición " + i + ": " + intNum[i]);
         System.out.println("----------------------------------------------------------");
        
        long [] longNum = new long [5];
        
        longNum [0] = 5;
        longNum [1] = 4;
        longNum [2] = 3;
        longNum [3] = 2;
        longNum [4] = 1;
        
         for (int i = 0; i < longNum.length; i++)
            System.out.println("el dato tipo long en la posición " + i + ": " + longNum[i]);
         System.out.println("----------------------------------------------------------");
         
        float [] floatNum = new float [5];
        
        floatNum [0] = 27.5f;
        floatNum [1] = 4.4f;
        floatNum [2] = 30.3f;
        floatNum [3] = 24.7f;
        floatNum [4] = 7.5f;
        
         for (int i = 0; i < floatNum.length; i++)
            System.out.println("el dato tipo float en la posición " + i + ": " + floatNum[i]);
         System.out.println("----------------------------------------------------------");
         
        double [] doubleNum = new double [5];
        
        doubleNum [0] = 6.6;
        doubleNum [1] = 8.4;
        doubleNum [2] = 9.7;
        doubleNum [3] = 7.7;
        doubleNum [4] = 4.5;
        
         for (int i = 0; i < doubleNum.length; i++)
            System.out.println("el dato tipo double en la posición " + i + ": " + doubleNum[i]);
          System.out.println("----------------------------------------------------------");
          
        String [] texto = new String [5];
        
        texto [0] = "Diego";
        texto [1] = "Haru";
        texto [2] = "Pablo";
        texto [3] = "Chayanne";
        texto [4] = "Chico gel";
        
         for (int i = 0; i < texto.length; i++)
            System.out.println("el dato tipo String en la posición " + i + ": " + texto[i]);
         System.out.println("----------------------------------------------------------");
    
        Object [] objectVar = new Object [5];
        
        objectVar [0] = 4;
        objectVar [1] = "Carlos";
        objectVar [2] = 29.5;
        objectVar [3] = -154;
        objectVar [4] = 45;
        
         for (int i = 0; i < objectVar.length; i++)
            System.out.println("el dato tipo object en la posición " + i + ": " + objectVar[i]);
          System.out.println("-----------------------------fin-----------------------------");
          
          String [] dataStructs = {"Listas", "Colas", "Pilas", "Mapas", "Conjuntos"};
         
          for (int i = 0; i < dataStructs.length; i++)
            System.out.println("la estructura en la posición " + i + ": " + dataStructs[i]);
          System.out.println("----------------------------------------------------------");
          
          
          String [] Caracteristicas = new String [5];
          
          Scanner S = new Scanner(System.in);
          
          System.out.println("ingresar las caracteristicas de las estructuras de datos");
    
           for (int i = 0; i < Caracteristicas.length; i++){
               System.out.println("caracteristica numero " + (i+1) + ": ");
               Caracteristicas[i] = S.nextLine();
              
               }
           
           System.out.println("Valores de caracteristicas: ");
 for (int i = 0; i < Caracteristicas.length; i++){
     System.out.println("la caracteristica en la posición " + i + ":" +Caracteristicas[i]);
 }
        System.out.println("-------------------------------------------------------------");
        
S.close();

if (dataStructs.length != Caracteristicas.length) {
    System.out.println("las caracteristicas no se asocian con las estructuras");
    return;
    }
        System.out.println("elementos de las estructuras con sus caracteristicas: ");
        for (int i = 0; i < dataStructs.length; i++){
            System.out.println(dataStructs[i] + ": " + Caracteristicas[i]);
        }
        System.out.println("----------------------------------------------------------------");
        int [] ventas;
        
        Random r = new Random();
       
        int cantRandom = r.nextInt(10) + 1;
        
        ventas = new int[cantRandom]; 
             
        
      for (int i = 0; i < ventas.length; i++){
      ventas[i] = r.nextInt(1000) + 1;
      
    }
       System.out.println("ventas en total: " + ventas.length);
         for (int i = 0; i < ventas.length; i++){
             System.out.println("venta numero: " + i + ": " + ventas[i]);
}
         
         int totalVenta = 0;
         for (int v : ventas) {
          totalVenta += v;
    }
         System.out.println("el total de todas las ventas es: " + totalVenta);
         
         double promVentas = (double) totalVenta / ventas.length;
         System.out.println("el promedio en ventas es: " + promVentas);
         
         System.out.println("-------------------------------------------------");
         
         
        ventas_Class g = new ventas_Class(ventas);
        
        int suma = g.sumaVentas();
        int ventaMasAlta = g.ventAlt();
        int ventaMasBaja = g.ventBaj();
        double promedioDeVentas = g.promVentas();
        int NumCercano = g.NumCercanoProm();
       
        
        System.out.println("La suma de todas las ventas: " + suma);
        System.out.println("La venta más alta es: " + ventaMasAlta);
        System.out.println("La venta más baja es: " + ventaMasBaja);
        System.out.println("El promedio de ventas es: " + promedioDeVentas);
        System.out.println("El numero más cercano al promedio es:  " + NumCercano);
        System.out.println("------------------------------------------------------");
      
    g.OrdenarAscendentes();     
    System.out.println("ventas ascendentes: ");
        for (int v : ventas){
            System.out.println(v);
            }
       
    g.OrdenarDescendentes();
    System.out.println("ventas descendentes: ");
        for (int v : ventas){
            System.out.println(v);
            }
    g.desordenar();
    System.out.println("ventas desordenadas: ");
        for (int v : ventas){
            System.out.println(v);
            }
    g.OrdParesEImpares();
    System.out.println("ventas ordenadas primero pares y luego impares: ");
        for (int v : ventas){
            System.out.println(v);
            }
        
        }
    
          


}

             

             
             
   
         


    
    
    
    
    
    

         
         
         
         
         
         

    
    
    
    
    
    
    
    
